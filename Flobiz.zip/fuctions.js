function submit()
{
    // window.alert("Logged On");
    // <a href="home.html"></a>
    document.getElementById('submit'.style.display='block');
}
function date1()
{
    var d = new date();
    document.getElementById('date')=d;
}

